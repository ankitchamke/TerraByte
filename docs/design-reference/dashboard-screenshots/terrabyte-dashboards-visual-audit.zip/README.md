# TerraByte — Current Dashboard Screenshot Reference & Visual Audit

> **Capture Date**: November 8, 2026  
> **Environment**: Staging (`ubqgvhcfmrvnmrbllcom` / Local Vite dev server on port 5173)  
> **Target Viewport**: 1440 × 1000 Desktop (100% zoom, Headless Chrome 156 with CDP)  
> **Archive Package**: [`terrabyte-dashboards-visual-audit.zip`](./terrabyte-dashboards-visual-audit.zip)

---

## Executive Summary & Baseline Inventory

This visual audit establishes the authoritative visual baseline of TerraByte's three primary authenticated dashboards prior to the planned UI/UX redesign stage. 

In strict adherence to the project scope and constraints:
- **Zero code, database schema, or production mutations**: No application code, styling, routes, or database records were modified.
- **Authentic authentication flows**: Screenshots were captured via standard Supabase Auth session negotiation and role resolution.
- **Seeded evaluation data**: Displays realistic baseline assets including the registered multi-machine tractor fleet, verified technician profile, skills, ratings, and district service centre roster.

---

## Directory Organization & Downloadable ZIP

All visual assets are stored in the persistent directory:  
`docs/design-reference/dashboard-screenshots/`

```text
docs/design-reference/dashboard-screenshots/
├── README.md                                    # This visual index
├── terrabyte-dashboards-visual-audit.zip        # Complete ZIP archive containing all PNGs (1.1 MB)
├── farmer/
│   ├── 01-farmer-overview.png                   # Full-page scroll of Farmer Dashboard
│   ├── 02-farmer-welcome-and-breakdown-cta.png  # Header, greeting, DEMO DATA badge & Report CTA
│   ├── 03-farmer-equipment-fleet.png            # "My machines" fleet (3 registered machines)
│   ├── 04-farmer-service-helpline.png           # Service history, Helpline CTA & field helpline card
│   ├── 05-farmer-notifications-panel.png        # Interactive notification drawer (bell popup)
│   └── 06-farmer-marathi-localization.png       # Marathi (म) localized Devanagari typography
├── technician/
│   ├── 01-technician-overview.png               # Full-page scroll of Technician Workbench
│   ├── 02-technician-identity-verification.png  # Online/Busy toggle & In-person KYC card
│   ├── 03-technician-skills-and-workshops.png   # Verified skills badges & workshop governance
│   ├── 04-technician-ratings-and-feedback.png   # 4.9★ verified ratings card & review policy
│   ├── 05-technician-jobs-queue.png             # Incoming requests & Active jobs empty states
│   └── 06-technician-notifications-panel.png    # Interactive notification drawer (bell popup)
└── service-centre/
    ├── 01-service-centre-overview.png           # Full-page scroll of Service Centre Dashboard
    ├── 02-service-centre-metric-cards.png       # District status & 4 operational KPI summary cards
    ├── 03-service-centre-technician-workload.png# Technician workload roster (Santosh & Ramesh)
    ├── 04-service-centre-dispatch-table.png     # 8 Status filter tabs & Dispatch operations table
    └── 05-service-centre-notifications-panel.png# Interactive notification drawer (bell popup)
```

---

## 1. Farmer Dashboard

- **Dashboard Name**: Farmer Equipment & Breakdown Portal
- **Route Visited**: `/farmer`
- **Authenticated Role**: `farmer` (Devdas Gaikwad / `farmer.staging@terrabyte.app`)
- **Viewport Dimensions**: 1440 × 1000 (Desktop)

### Screenshot Inventory

| Filename | Capture Mode | Visible Components & Visual Elements |
| :--- | :--- | :--- |
| [`01-farmer-overview.png`](./farmer/01-farmer-overview.png) | Full Page (1440 × 1000) | Complete dashboard from top header to bottom helpline banner. Displays application branding, user identity, multilingual switcher (`EN / हिं / म`), settings icon, notification bell, demo reset button, sign-out button, `"Namaskar, Devdas"` greeting, `"DEMO DATA"` tag, prominent `"Report Equipment Breakdown"` action button, `"My machines"` section with 3 machinery cards, Service History & Helpline links, and rural helpline notice. |
| [`02-farmer-welcome-and-breakdown-cta.png`](./farmer/02-farmer-welcome-and-breakdown-cta.png) | Clipped Section (1440 × 313) | Top application bar and hero action area: Brand tractor logo, user role identification, `"Namaskar, Devdas"` greeting with amber `"DEMO DATA"` badge, and primary high-visibility `"Report Equipment Breakdown"` button (`"Takes under 2 minutes if something breaks."`). |
| [`03-farmer-equipment-fleet.png`](./farmer/03-farmer-equipment-fleet.png) | Clipped Section (768 × 362) | Registered machinery fleet section (`"My machines"` with `"Add / manage"` action). Shows 3 populated machines: <br>1. **Mahindra 575 DI** (Tractor · 2021 · 1,240 hrs · `Operational`)<br>2. **VST Shakti 130 DI** (Power Tiller · 2023 · 3,120 hrs · `Operational`)<br>3. **John Deere W70** (Harvester · 2020 · 890 hrs · `Operational`). Green status badges indicate operational status. |
| [`04-farmer-service-helpline.png`](./farmer/04-farmer-service-helpline.png) | Clipped Section (768 × 158) | Bottom utility actions: `"Service history"` button with clock-history icon, `"Helpline"` button with telephone icon, and the rural advisory card: *"No signal in the field? Call the TerraByte helpline 1800-200-1234 (demo) and we'll log the breakdown for you."* |
| [`05-farmer-notifications-panel.png`](./farmer/05-farmer-notifications-panel.png) | Viewport Interactive State (1440 × 1000) | Opened notifications dropdown drawer anchored to the bell icon. Shows header with unread counter, `"Mark all as read"`, and caught-up state (*"No notifications · You're all caught up"*). |
| [`06-farmer-marathi-localization.png`](./farmer/06-farmer-marathi-localization.png) | Full Page (1440 × 1000) | Complete localized dashboard rendering after toggling to Marathi (`म`). Demonstrates Noto Sans Devanagari typography: *"नमस्कार, Devdas"*, *"उपकरणांचे ब्रेकडाउन कळवा"*, *"माझी उपकरणे"*, *"चालू स्थिती"*, and localized footer helpline instructions. |

### Data State & Observations
- **Equipment**: Fully populated with 3 realistic agricultural machines (Tractor, Power Tiller, Harvester) with serial numbers, hour meters, and model years.
- **Active Repairs**: Clean baseline (0 active repairs). Under Phase 8b/9 architectural invariants, hardcoded fake sample tickets (e.g. `TB-8841`) were purged to preserve database referential integrity.
- **Unavailable Sections / Blockers**: None.

---

## 2. Technician Dashboard

- **Dashboard Name**: Field Technician Job Workbench
- **Route Visited**: `/technician`
- **Authenticated Role**: `technician` (Santosh Kale / `tech.staging@terrabyte.app`)
- **Affiliated Workshop**: Kale Agro Services
- **Viewport Dimensions**: 1440 × 1000 (Full-page document height: 1591px)

### Screenshot Inventory

| Filename | Capture Mode | Visible Components & Visual Elements |
| :--- | :--- | :--- |
| [`01-technician-overview.png`](./technician/01-technician-overview.png) | Full Page (1440 × 1591) | Complete vertical workbench scroll. Header shell, Santosh Kale title with Kale Agro Services workshop, `"DEMO DATA"` badge, green `● Online` / `Busy` toggle bar, In-Person Physical Identity Verification card, Verified Technical Skills card, Affiliated Workshops & Bays card, Verified Ratings & Farmer Feedback summary, Incoming requests feed, and Active jobs feed. |
| [`02-technician-identity-verification.png`](./technician/02-technician-identity-verification.png) | Clipped Section (1440 × 737) | Application header, technician workshop title, two-state availability toggle (`● Online` active in green, `Busy` inactive), and the comprehensive physical identity verification card (*"Identity & Trust Verification · In-Person Audit Pending"*). Details accepted physical documents (Aadhaar last 4 digits, PAN, Voter ID, Commercial Driving Licence, Trade Licence) and explains the privacy-conscious zero-upload policy. |
| [`03-technician-skills-and-workshops.png`](./technician/03-technician-skills-and-workshops.png) | Clipped Section (768 × 526) | Verified Technical Skills card showing tags (`Tractors`, `Hydraulics`, `Engine Overhaul`) marked *"Visible on public dispatch card"*, and Affiliated Workshops & Bays card with `"Register New Workshop"` action and guidance for registering repair bays. |
| [`04-technician-ratings-and-feedback.png`](./technician/04-technician-ratings-and-feedback.png) | Clipped Section (768 × 306) | Verified Ratings & Farmer Feedback card showing **4.9 ★** overall rating, **42** repairs completed, and 0 customer reviews, along with the explanation of the post-repair review gate. |
| [`05-technician-jobs-queue.png`](./technician/05-technician-jobs-queue.png) | Clipped Section (768 × 252) | Job dispatch feeds: `"Incoming requests (0)"` with empty state card (*"No new requests. Stay online to receive jobs."*) and `"Active jobs (0)"` with empty state card (*"No active jobs."*). |
| [`06-technician-notifications-panel.png`](./technician/06-technician-notifications-panel.png) | Viewport Interactive State (1440 × 1000) | Opened technician notifications drawer showing alert feed and unread notifications management. |

### Data State & Observations
- **Technician Profile & Stats**: Fully populated with verified status, 4.9 rating, 42 historical completed repairs, and certified system tags (Tractors, Hydraulics, Engine Overhaul).
- **KYC Status**: Correctly reflects the in-person audit state mandated by Phase 13 privacy regulations.
- **Active Jobs**: 0 in baseline.
- **Unavailable Sections / Blockers**: None.

---

## 3. Service Centre Dashboard

- **Dashboard Name**: Service Centre Operations Command (Nagpur Central)
- **Route Visited**: `/admin`
- **Authenticated Role**: `service_centre` / `admin` (Rahul Patil / `admin.staging@terrabyte.app`)
- **District Context**: Nagpur District · Live Operations
- **Viewport Dimensions**: 1440 × 1000 (Desktop)

### Screenshot Inventory

| Filename | Capture Mode | Visible Components & Visual Elements |
| :--- | :--- | :--- |
| [`01-service-centre-overview.png`](./service-centre/01-service-centre-overview.png) | Full Page (1440 × 1000) | Complete central operations command overview. Header shell with Rahul Patil identity, `"NAGPUR DISTRICT · LIVE"` subheader, quick navigation pill links (`Repair operations`, `Parts Desk`, `Workshops & Bays`, `Technician accounts`), `"DEMO DATA"` badge, 4 primary operational KPI cards, Technician workload / roster grid, 8 status filter tabs, and the full repair operations dispatch table. |
| [`02-service-centre-metric-cards.png`](./service-centre/02-service-centre-metric-cards.png) | Clipped Section (1280 × 114) | 4 Key Performance Indicator (KPI) cards: <br>1. **Unassigned / open requests**: `0`<br>2. **Active repairs**: `0`<br>3. **Waiting for parts**: `0`<br>4. **Avg. downtime (hrs)**: `—`. |
| [`03-service-centre-technician-workload.png`](./service-centre/03-service-centre-technician-workload.png) | Clipped Section (1280 × 213) | Technician workload and district roster card (*"2 active in district"*). Displays active technician cards: <br>• **Santosh Kale** (Kale Agro Services · Online · 0 active jobs · 0% load)<br>• **Ramesh Kumar** (Ramesh Kumar Workshop · Online · 0 active jobs · 0% load). |
| [`04-service-centre-dispatch-table.png`](./service-centre/04-service-centre-dispatch-table.png) | Clipped Section (1280 × 203) | Operations dispatch table and filter tabs. Displays 8 status filters: `All (0)`, `Unassigned (0)`, `Awaiting Quote (0)`, `Waiting for Parts (0)`, `Cancellation Requests (0)`, `Overdue (0)`, `Completed (0)`, `Cancelled (0)`, and the table headers: `JOB`, `MACHINE`, `FARMER`, `TECHNICIAN`, `STATUS`, `TIME IN STATUS`. |
| [`05-service-centre-notifications-panel.png`](./service-centre/05-service-centre-notifications-panel.png) | Viewport Interactive State (1440 × 1000) | Opened service centre operations notifications drawer anchored to header bell icon. |

### Data State & Observations
- **District Roster**: 2 certified technicians actively monitored (Santosh Kale and Ramesh Kumar) with live online status indicators and workload capacity gauges.
- **Operations Board**: 0 active repair requests in baseline.
- **Unavailable Sections / Blockers**: None.

---

## Technical Audit & Methodology Notes

1. **Browser Environment & Fidelity**:
   - Engine: Headless Google Chrome v156 (Windows NT 10.0 x64).
   - Remote Debugging: Direct Chrome DevTools Protocol (CDP) WebSocket communication.
   - Screen Metrics: Exactly `1440 × 1000` desktop resolution with `deviceScaleFactor: 1` (100% zoom).
   - Layout & Font Loading: Enforced `document.fonts.ready` synchronization and React component hydration before screenshot capture.
2. **Prototype Banner Handling**:
   - The non-operational `Prototype in Active Development` floating toast was dismissed programmatically (`terrabyte.prototype-status-dismissed = 'true'`) to avoid obscuring any dashboard navigation or interface elements.
3. **Database & Application Integrity**:
   - **Zero code changes**: No React components, CSS stylesheets, TanStack Router definitions, or API endpoints were modified.
   - **Zero database changes**: Staging database (`ubqgvhcfmrvnmrbllcom`) and production environments were left untouched.
   - **Zero fake operational injection**: Followed Phase 8b/9 architectural guidelines prohibiting artificial dummy repair tickets.
